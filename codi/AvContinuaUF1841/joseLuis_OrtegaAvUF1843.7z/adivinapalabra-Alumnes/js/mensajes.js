const msg = [
  {primero: `Enhorabuena! Encontraste la palabra "`,segundo:`". Has ganado, pero en realidad has perdido (tu tiempo)`},
  {primero:`Enhorabuena! Encontraste la palabra "`,segundo:`". Deja de jugar a esto y echa un Euromillón ... a ver si sales "probre"`},
  {primero:`Enhorabuena! Encontraste la palabra "`,segundo:`".  Deja de jugar a esto y prueba a lamer un ladrillo`},
  {primero:`Enhorabuena! Encontraste la palabra "`,segundo:`". Este juego no tiene secretos para ti`},
  {primero:`Enhorabuena! Encontraste la palabra "`,segundo:`".  Un gallifante para ti!!`},
  {primero:`Enhorabuena! Encontraste la palabra "`,segundo:`".  Has ganado un chorizo poco chupado`},
];
const msgError = [
  {primero:`Has fallado. La palabra correcta era "`,segundo:`". Esto es demasiado para un... como tú`},
  {primero:`Has fallado OTRA VEZ!!!. La palabra correcta era "`,segundo:`". Deberías dedicar tu tiempo a otras cosas`},
  {primero:`Has fallado. La palabra correcta era "`,segundo:`".. Las adivinanzas no son lo tuyo!!!`},
  {primero:`Has fallado. La palabra correcta era "`,segundo:`".... Zumo de Gato`},
  {primero:`Has fallado por no leer bien la pista, La palabra correcta era "`,segundo:`".... más fácil no puede ser esto!!!`},
  {primero:`Has fallado. La palabra correcta era "`,segundo:`".... y resulta que las cosas no son lo que parecen`},
];
